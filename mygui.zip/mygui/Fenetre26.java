package mygui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import essai.MyFrame;

public class Fenetre26 extends JFrame {
	
	private JPanel pNorth;
	private JLabel lConnexion;
	
	private JPanel panelCenter;
	private JLabel lLogin;
	private JTextField txtLogin;
	private JLabel lPassword;
	private JPasswordField txtPassword;
	
	private JPanel pSouth;
	private JButton bOk;
	private JButton bNouveau;
	private JButton bFermer;


	public Fenetre26(String titre) {
		super(titre);
		initGUI();
	}


	public void initGUI() {
		// create north panel
		pNorth = new JPanel();
		lConnexion = new JLabel("Connexion");
		pNorth.add(lConnexion);
		this.add(pNorth, BorderLayout.NORTH);
		
		
		// create center panel
		panelCenter = new JPanel();
		panelCenter.setLayout(new GridLayout(2, 2));
		lLogin = new JLabel("Login");
		panelCenter.add(lLogin);
		txtLogin = new JTextField("Donner votre Login");
		panelCenter.add(txtLogin);
		
		lPassword = new JLabel("Password");
		panelCenter.add(lPassword);
		txtPassword = new JPasswordField("             ");
		panelCenter.add(txtPassword);
		
		this.add(panelCenter, BorderLayout.CENTER);
		
		// create south panel
		pSouth = new JPanel();
		pSouth.setLayout(new FlowLayout());
		bOk = new JButton("Ok");
		bOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Vous avez clique sur " + bOk.getActionCommand());
			}
		});
		pSouth.add(bOk);
		bNouveau = new JButton("Nouveau");
		bNouveau.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame frame = new MyFrame("Welcome");
				frame.setSize(100, 150);
				frame.setVisible(true);
			}
		});
		pSouth.add(bNouveau);
		bFermer = new JButton("Fermer");
		bFermer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Vous avez clique sur " + bFermer.getActionCommand());
				System.exit(0);
			}
		});
		pSouth.add(bFermer);
		this.add(pSouth, BorderLayout.SOUTH);
		this.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("Clic au point (" + e.getX() + ", " + getY() + ") de la fenetre");
			}
		});

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//this.setSize(600, 400);
		this.pack();
		this.setVisible(true);
	}



}
