package mygui;

import java.awt.*;

import javax.swing.*;

public class Fenetre1 {

	public static void main(String[] args) {
//		JFrame f = new JFrame();
//		f.setTitle("Ma Fenetre");
		JFrame f = new JFrame("Ma Fenetre");
		//f.setLayout(new FlowLayout());
		f.setLayout(new BorderLayout());
		
		JButton bOk = new JButton("OK");
		f.add(bOk, BorderLayout.NORTH);
		
		JPanel panelSud = new JPanel();
		
		JLabel lNom = new JLabel("Nom");
		panelSud.add(lNom);
		
		JTextField txtNom = new JTextField("sAISIR NOM");
		panelSud.add(txtNom);
		
		panelSud.setBackground(Color.CYAN);
		
		f.add(panelSud, BorderLayout.SOUTH);
		
		JButton bFermer = new JButton("Fermer");
		f.add(bFermer);
		
		f.setSize(200, 400);
		f.setLocation(100, 200);
		f.setVisible(true);
	}

}

