package mygui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class Fenetre24 extends JFrame {
	
	private JPanel pNorth;
	private JLabel lConnexion;
	
	private JPanel panelCenter;
	JLabel lLogin;
	JTextField txtLogin;
	JLabel lPassword;
	JPasswordField txtPassword;
	
	private JPanel pSouth;

	public Fenetre24(String titre) {
		// create frame
		super(titre);
		
		// create north panel
		pNorth = new JPanel();
		lConnexion = new JLabel("Connexion");
		pNorth.add(lConnexion);
		this.add(pNorth, BorderLayout.NORTH);
		
		
		// create center panel
		panelCenter = new JPanel();
		panelCenter.setLayout(new GridLayout(2, 2));
		lLogin = new JLabel("Login");
		panelCenter.add(lLogin);
		txtLogin = new JTextField("Donner votre Login");
		panelCenter.add(txtLogin);
		
		lPassword = new JLabel("Password");
		panelCenter.add(lPassword);
		txtPassword = new JPasswordField("             ");
		panelCenter.add(txtPassword);
		
		this.add(panelCenter, BorderLayout.CENTER);
		
		// create south panel
		JPanel pSouth = new JPanel();
		pSouth.setLayout(new FlowLayout());
		JButton bOk = new JButton("Ok");
		pSouth.add(bOk);
		JButton bAnnuler = new JButton("Annuler");
		pSouth.add(bAnnuler);
		JButton bFermer = new JButton("Fermer");
		pSouth.add(bFermer);
		this.add(pSouth, BorderLayout.SOUTH);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//this.setSize(600, 400);
		this.pack();
		this.setVisible(true);
	}




}
