package mygui;

import javax.swing.JFrame;

public class TestFenetre2 {

	public static void main(String[] args) {
		//new Fenetre21().main(null);
		//Fenetre21.main(null);
		
		//new Fenetre22();
		
		//new Fenetre23("Test connexion");
		
		//Fenetre34 f = new Fenetre34("Ma Fenetre");
		//f.setSize(300, 250);
		
		new Fenetre35();
	}
}
