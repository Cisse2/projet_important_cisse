package mygui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Fenetre22 {

	public Fenetre22() {
		// create frame
		JFrame frame = new JFrame("Connexion");
		
		// create north panel
		JPanel pNorth = new JPanel();
		JLabel lConnexion = new JLabel("Connexion");
		pNorth.add(lConnexion);
		frame.add(pNorth, BorderLayout.NORTH);
		
		
		// create center panel
		JPanel panelCenter = new JPanel();
		panelCenter.setLayout(new GridLayout(2, 2));
		JLabel lLogin = new JLabel("Login");
		panelCenter.add(lLogin);
		JTextField txtLogin = new JTextField("Donner votre Login");
		panelCenter.add(txtLogin);
		
		JLabel lPassword = new JLabel("Password");
		panelCenter.add(lPassword);
		JPasswordField txtPassword = new JPasswordField("             ");
		panelCenter.add(txtPassword);
		
		frame.add(panelCenter, BorderLayout.CENTER);
		
		// create south panel
		JPanel pSouth = new JPanel();
		pSouth.setLayout(new FlowLayout());
		JButton bOk = new JButton("Ok");
		pSouth.add(bOk);
		JButton bAnnuler = new JButton("Annuler");
		pSouth.add(bAnnuler);
		JButton bFermer = new JButton("Fermer");
		pSouth.add(bFermer);
		frame.add(pSouth, BorderLayout.SOUTH);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.setSize(600, 400);
		frame.pack();
		frame.setVisible(true);
	}


}
