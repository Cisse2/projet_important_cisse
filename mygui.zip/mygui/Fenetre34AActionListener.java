package mygui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import essai.MyFrame;

public class Fenetre34AActionListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == Fenetre31.bOk.getText()) {
			System.out.println("Vous avez clique sur " + Fenetre31.bOk.getActionCommand());
		}
		else if (e.getActionCommand() == Fenetre31.bFermer.getText()) {
			System.out.println("Vous avez clique sur " + Fenetre31.bFermer.getActionCommand());
			System.exit(0);
		}
	}

}
