package mygui;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Fenetre33MouseListener extends MouseAdapter {

	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println("Clic au point (" + e.getX() + ", " + e.getY() + ") de la fenetre");
	}
}
