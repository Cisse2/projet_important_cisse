# Load R packages
library(shiny)
library(shinythemes)
library("FactoMineR")


  # Define UI
  ui <- fluidPage(theme = shinytheme("superhero"),
    titlePanel("Plateforme de téléchargement de données"),
    navbarPage(
      # theme = "cerulean",  # <--- To use a theme, uncomment this
      "TDSI projet",
      tabPanel("Acceuil",
               sidebarLayout(
                 
                 # Sidebar panel pour les inputs ----
                 sidebarPanel(
                   
                   # Input: Choix sur les types de données ----
                   selectInput("dataset", "Choix sur les types données à télécharger:",
                               choices = c("rock", "pressure", "cars")),#Des bases de données distant disponible sur Rstudio
                   
                   # Boutton de téléchargement
                   downloadButton("downloadData", "Télécharger")
                   
                 ),
                 
                 # panel principal pour afficher les données ----
                 mainPanel(
                   
                   tableOutput("table"),
                   
                 )
                 
               )
      ), # Navbar 1, tabPanel
      tabPanel("Analyse Descriptive", 
               sidebarLayout(
                 
                 # Sidebar panel for inputs ----
                 sidebarPanel(
                   
                   # Input: Slider for the number of bins ----
                   sliderInput(inputId = "bins",
                               label = "Number of bins:",
                               min = 0,
                               max = 50,
                               value = 25,
                               step = 5)
                   
                 ),
                 
                 # Main panel for displaying outputs ----
                 mainPanel(
                   
                   # Output: Histogram ----
                   plotOutput(outputId = "distPlot"),
                 )
               )
               
      ),
      tabPanel("AFC",""),
      tabPanel("Regression linéaire", "This panel is intentionally left blank")
    ) # navbarPage
  ) # fluidPage

  
  # Partie server  
  server <- function(input, output) {
    
    # les valeurs Reactive pour le type de données choisie ----
    datasetInput <- reactive({
      switch(input$dataset,
             "rock" = rock,
             "pressure" = pressure,
             "cars" = cars)
    })
    
    output$distPlot <- renderPlot({
    
    x    <- datasetInput()[,1]
    x    <- na.omit(x)
    bins <- seq(min(x), max(x), length.out = input$bins + 1)
    
    hist(x, breaks = bins, col = "#75AADB", border = "black",
         xlab = "Description des données",
         main = "Histogram des données")
    
  })
    
    # Table des données ----
    output$table <- renderTable({
      datasetInput()
    })
    
    # Rendre dles données téléchargeable en fichier csv ----
    output$downloadData <- downloadHandler(
      filename = function() {
        paste(input$dataset, ".csv", sep = "")
      },
      content = function(file) {
        write.csv(datasetInput(), file, row.names = FALSE)
      }
    )
  } # server
  

  # Creation de l'objet Shiny
  shinyApp(ui = ui, server = server)
